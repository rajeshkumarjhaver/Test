package com.lbg.conf;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

import waffle.servlet.spi.NegotiateSecurityFilterProvider;
import waffle.servlet.spi.SecurityFilterProvider;
import waffle.servlet.spi.SecurityFilterProviderCollection;
import waffle.spring.NegotiateSecurityFilterEntryPoint;
import waffle.spring.NegotiateSecurityFilter;
import waffle.windows.auth.impl.WindowsAuthProviderImpl;


@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

    @Autowired 
    private NegotiateSecurityFilterEntryPoint authenticationEntryPoint;

    @Autowired
    private NegotiateSecurityFilter securityFilter;

    @Override
    public void configure(final WebSecurity web) throws Exception {
        web.ignoring()
            .antMatchers("/styles/**")
            .antMatchers("/lib/**")
            .antMatchers("/scripts/**");
    }

    @Override
    protected void configure(final HttpSecurity http) throws Exception {
        http
                .authorizeRequests()
                    .anyRequest().authenticated()
                    .and()
                .addFilterBefore(this.securityFilter, NegotiateSecurityFilter.class) //BasicAuthenticationFilter               
                .httpBasic()
                    .authenticationEntryPoint(this.authenticationEntryPoint);
    }

    @Bean
    public WindowsAuthProviderImpl waffleWindowsAuthProvider() {
        return new WindowsAuthProviderImpl();
    }

    @Bean
    @Autowired
    public NegotiateSecurityFilterProvider negotiateSecurityFilterProvider(final WindowsAuthProviderImpl windowsAuthProvider) {
    	NegotiateSecurityFilterProvider obj = new NegotiateSecurityFilterProvider(windowsAuthProvider);
    	final List<String> protocolList = new ArrayList<>();
    	protocolList.add("Negotiate");
    	protocolList.add("NTLM");    	 
    	obj.setProtocols(protocolList);
        return obj;
    }

    @Bean
    @Autowired
    public SecurityFilterProviderCollection waffleSecurityFilterProviderCollection(final NegotiateSecurityFilterProvider negotiateSecurityFilterProvider) {
        final List<SecurityFilterProvider> securityFilterProviders = new ArrayList<>();
        securityFilterProviders.add(negotiateSecurityFilterProvider);
        return new SecurityFilterProviderCollection(securityFilterProviders.toArray(new SecurityFilterProvider[]{}));
    }

    @Bean
    @Autowired
    public NegotiateSecurityFilterEntryPoint negotiateSecurityFilterEntryPoint(final SecurityFilterProviderCollection securityFilterProviderCollection) {
        final NegotiateSecurityFilterEntryPoint negotiateSecurityFilterEntryPoint = new NegotiateSecurityFilterEntryPoint();
        negotiateSecurityFilterEntryPoint.setProvider(securityFilterProviderCollection);
        return negotiateSecurityFilterEntryPoint;
    }

    @Bean
    @Autowired
    public waffle.spring.NegotiateSecurityFilter waffleNegotiateSecurityFilter(final SecurityFilterProviderCollection securityFilterProviderCollection) {
        final NegotiateSecurityFilter negotiateSecurityFilter = new NegotiateSecurityFilter();
        negotiateSecurityFilter.setProvider(securityFilterProviderCollection);
        return negotiateSecurityFilter;
    }
}
