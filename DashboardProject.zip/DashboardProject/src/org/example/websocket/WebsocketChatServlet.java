/**
 * Chat servlet that creates the MessageInbound instances and creates the repository that manages all the
 * clients.
 */
package org.example.websocket;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.catalina.websocket.StreamInbound;
import org.apache.catalina.websocket.WebSocketServlet;
import org.example.model.ChatMessageInbound;
import org.example.model.ClientsRepository;

public class WebsocketChatServlet extends WebSocketServlet {
    private ClientsRepository repository;

    @Override
    public void init() throws ServletException {
        super.init();
        repository = new ClientsRepository();
    }

    @Override
    protected StreamInbound createWebSocketInbound(String subProtocol, HttpServletRequest httpServletRequest) {
    	System.out.println("createWebSocketInbound");
        return new ChatMessageInbound(repository);
    }
}