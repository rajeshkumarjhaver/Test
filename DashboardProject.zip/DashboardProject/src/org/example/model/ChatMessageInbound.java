package org.example.model;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;

import org.apache.catalina.websocket.MessageInbound;
import org.apache.catalina.websocket.WsOutbound;

/**
 * This class represents a client, each client has a link to the repository that contains all clients
 */
public class ChatMessageInbound extends MessageInbound {
    private ClientsRepository repository;

    public ChatMessageInbound(ClientsRepository repository) {
        this.repository = repository;
    }

    @Override
    protected void onTextMessage(CharBuffer message) throws IOException {
        repository.sendMessageToAll(message);
    }

    @Override
    protected void onBinaryMessage(ByteBuffer message) throws IOException {
        // no-op
    }


    @Override
    protected void onOpen(WsOutbound outbound) {
    	System.out.println("onOpen");
        repository.sendMessageToAll(CharBuffer.wrap("New client connected"));
        repository.addClient(this);
    }

    @Override
    protected void onClose(int status) {
    	System.out.println("onClose");
        repository.removeClient(this);
        repository.sendMessageToAll(CharBuffer.wrap("Lost a client"));
    }
}
